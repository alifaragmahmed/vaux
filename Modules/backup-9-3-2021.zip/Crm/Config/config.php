<?php

return [
    'name' => 'Crm',
    'module_version' => "0.7",
    'pid' => 7
];
