<?php

return [

    'shippings' => 'Shippings',
    'list_shipping_companies' => 'List Shipping Companies',
    'create_fees' => 'Create Fees',
    'list_fees' => 'List Fees',
    'shipping_zones' => 'Shipping zones',
    'shipping_company' => 'Shipping company',
    'zone_name' => 'Zone name',
    'company_name' => 'Company name',
    'add_company' => 'Add Company',
    'edit_company' => 'Edit Company',
    'amount' => 'Amount',
    'areas' => 'Areas',
    'settle' => 'Settle',
    'all_shipping_zones' => 'All shipping zones',

];
